(() => {
  const RESOURCE_NAME = 'grs-ids';
  const CLOSE_ANIM_MS = 220;

  const body = document.body;
  const menu = document.getElementById('menu');
  const viewerName = document.getElementById('viewerName');
  const myIdEl = document.getElementById('myId');
  const tableBody = document.getElementById('tableBody');

  let closing = false;

  function renderList(list) {
    tableBody.innerHTML = '';

    if (!list || list.length === 0) {
      tableBody.innerHTML = '<div class="empty-state">No hay jugadores registrados</div>';
      return;
    }

    const fragment = document.createDocumentFragment();

    for (const player of list) {
      const row = document.createElement('div');
      row.className = 'table-row';

      const name = document.createElement('span');
      name.className = 'player-name';
      name.textContent = player.name || 'Desconocido';

      const id = document.createElement('span');
      id.className = 'player-id';
      id.textContent = '#' + player.id;

      row.appendChild(name);
      row.appendChild(id);
      fragment.appendChild(row);
    }

    tableBody.appendChild(fragment);
  }

  function openMenu(data) {
    closing = false;
    viewerName.textContent = data.myName || 'Steam';
    myIdEl.textContent = data.myId ? ('#' + data.myId) : '#-';
    renderList(data.list);
    body.classList.add('visible');
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        menu.classList.add('open');
      });
    });
  }

  function closeMenu() {
    if (closing) return;
    closing = true;

    menu.classList.remove('open');

    setTimeout(() => {
      body.classList.remove('visible');
      fetch(`https://${RESOURCE_NAME}/close`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify({})
      }).catch(() => {});
    }, CLOSE_ANIM_MS);
  }

  window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || !data.action) return;

    if (data.action === 'open') {
      openMenu(data);
    } else if (data.action === 'close') {
      closeMenu();
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeMenu();
    }
  });
})();