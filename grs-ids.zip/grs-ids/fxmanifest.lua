fx_version 'cerulean'
game 'gta5'
lua54 'yes'
version '1.2.0'

author 'Guerrero'

shared_scripts { 'config.lua' }

server_scripts { '@oxmysql/lib/MySQL.lua' , 'server/*.lua' }

client_scripts { 'client/*.lua' }

ui_page 'web/index.html'

files { 'web/**/**/*.*' }

escrow_ignore { 'config.lua' }