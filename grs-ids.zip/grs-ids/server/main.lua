local PlayerPermanentId = {}

local ListCache = {
    data = nil,
    expiresAt = 0
}

local function debugPrint(msg)
    if Config.Debug then
        print(('^3[grs-ids]^7 %s'):format(msg))
    end
end

local Framework, FrameworkObject

local function DetectFramework()
    if Framework then return end

    if GetResourceState('es_extended') == 'started' then
        Framework = 'esx'
        FrameworkObject = exports['es_extended']:getSharedObject()
    elseif GetResourceState('qbx_core') == 'started' then
        Framework = 'qbox'
        FrameworkObject = exports['qbx_core']:GetCoreObject()
    elseif GetResourceState('qb-core') == 'started' then
        Framework = 'qbcore'
        FrameworkObject = exports['qb-core']:GetCoreObject()
    else
        Framework = 'none'
        debugPrint('Config.PermissionMode = "group" pero no se detectó ningún framework compatible (ESX/QBCore/qbox). Usa "ace" en su lugar.')
    end
end

local function GetPlayerGroup(src)
    DetectFramework()

    if Framework == 'esx' and FrameworkObject then
        local xPlayer = FrameworkObject.GetPlayerFromId(src)
        return xPlayer and xPlayer.getGroup() or nil
    elseif (Framework == 'qbcore' or Framework == 'qbox') and FrameworkObject then
        local Player = FrameworkObject.Functions.GetPlayer(src)
        return Player and Player.PlayerData and Player.PlayerData.permission or nil
    end

    return nil
end

local function IsAdmin(src)
    if Config.PermissionMode == 'group' then
        local group = GetPlayerGroup(src)
        if not group then return false end

        for _, allowedGroup in ipairs(Config.AdminGroups) do
            if group == allowedGroup then
                return true
            end
        end

        return false
    end
    return IsPlayerAceAllowed(src, Config.AdminPermission)
end

local function NotifyClient(src, msg, notifyType)
    notifyType = notifyType or 'inform'
    DetectFramework()

    if Framework == 'esx' then
        TriggerClientEvent('esx:showNotification', src, msg)
    elseif Framework == 'qbcore' or Framework == 'qbox' then
        TriggerClientEvent('QBCore:Notify', src, msg, notifyType)
    else
        TriggerClientEvent('chat:addMessage', src, {
            args = { '^2GRS-IDs', msg }
        })
    end
end

local function GetIdentifier(src)
    local identifiers = GetPlayerIdentifiers(src)
    for _, id in ipairs(identifiers) do
        if string.find(id, Config.Identifier .. ':') then
            return id
        end
    end
    return nil
end

local function EnsurePermanentId(identifier, name)
    local insertId = MySQL.insert.await(
        'INSERT IGNORE INTO ' .. Config.TableName .. ' (identifier, name) VALUES (?, ?)',
        { identifier, name }
    )
    local isNew = insertId ~= nil and insertId > 0
    if not isNew then
        MySQL.update.await(
            'UPDATE ' .. Config.TableName .. ' SET name = ? WHERE identifier = ?',
            { name, identifier }
        )
    end

    local result = MySQL.query.await(
        'SELECT id FROM ' .. Config.TableName .. ' WHERE identifier = ?',
        { identifier }
    )

    if result and result[1] then
        if isNew then
            ListCache.data = nil
        end
        return result[1].id
    end

    return nil
end

local function GetCachedList()
    local now = GetGameTimer()

    if ListCache.data and now < ListCache.expiresAt then
        return ListCache.data
    end

    local rows = MySQL.query.await(
        'SELECT id, name FROM ' .. Config.TableName .. ' ORDER BY id ASC'
    ) or {}

    ListCache.data = rows
    ListCache.expiresAt = now + Config.CacheTTL

    return rows
end

local function BroadcastIdsMap(targetSrc)
    local list = {}
    for src, id in pairs(PlayerPermanentId) do
        list[#list + 1] = { src = src, id = id }
    end

    TriggerClientEvent('grs-ids:syncIds', targetSrc or -1, list)
end

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local src = source

    deferrals.defer()
    Wait(0)

    deferrals.update('Verificando tu ID permanente...')

    local identifier = GetIdentifier(src)

    if not identifier then
        deferrals.done(('No se pudo obtener tu identificador (%s). Reinicia FiveM e inténtalo de nuevo.'):format(Config.Identifier))
        return
    end
    local ok, permanentId = pcall(EnsurePermanentId, identifier, name)

    if not ok or not permanentId then
        debugPrint('Error asignando ID permanente para ' .. identifier)
        deferrals.done('Ocurrió un error asignando tu ID permanente. Contacta con un administrador.')
        return
    end
    PlayerPermanentId[src] = permanentId
    debugPrint(('%s (%s) conectado con ID permanente #%d'):format(name, identifier, permanentId))

    deferrals.done()
end)

AddEventHandler('playerDropped', function()
    local src = source
    PlayerPermanentId[src] = nil
    BroadcastIdsMap()
end)

RegisterServerEvent('grs-ids:requestId')
AddEventHandler('grs-ids:requestId', function()
    local src = source
    local id = PlayerPermanentId[src]

    if not id then
        local identifier = GetIdentifier(src)
        if identifier then
            id = EnsurePermanentId(identifier, GetPlayerName(src))
            PlayerPermanentId[src] = id
        end
    end

    TriggerClientEvent('grs-ids:setId', src, id)
    BroadcastIdsMap()

    if Config.NotifyOnJoin and id then
        NotifyClient(src, ('Tu ID permanente en este servidor es: #%d'):format(id), 'success')
    end
end)

RegisterCommand(Config.Command, function(source)
    local src = source
    if src == 0 then return end

    local id = PlayerPermanentId[src]
    if id then
        NotifyClient(src, ('Tu ID es: #%d'):format(id), 'success')
    else
        NotifyClient(src, 'Aún no se ha asignado tu ID, espera unos segundos.', 'error')
    end
end, false)

RegisterServerEvent('grs-ids:toggleViewIds')
AddEventHandler('grs-ids:toggleViewIds', function()
    local src = source

    if Config.ViewIdsAdminOnly and not IsAdmin(src) then
        NotifyClient(src, 'No tienes permiso para usar este comando.', 'error')
        debugPrint(('%s intentó usar /verid sin permiso.'):format(GetPlayerName(src)))
        return
    end

    BroadcastIdsMap(src)
    TriggerClientEvent('grs-ids:toggleViewIdsClient', src)
end)

RegisterCommand(Config.ViewIdsCommand, function(source)
    if source == 0 then
        print('Este comando solo puede usarse dentro del juego.')
    end
end, false)

RegisterServerEvent('grs-ids:requestOpen')
AddEventHandler('grs-ids:requestOpen', function()
    local src = source

    if not IsAdmin(src) then
        NotifyClient(src, 'No tienes permiso para usar este comando.', 'error')
        debugPrint(('%s intentó abrir el panel admin sin permiso.'):format(GetPlayerName(src)))
        return
    end

    local list = GetCachedList()

    TriggerClientEvent('grs-ids:openMenu', src, {
        myId = PlayerPermanentId[src],
        myName = GetPlayerName(src),
        list = list
    })
end)

RegisterCommand(Config.AdminCommand, function(source)
    if source == 0 then
        print('Este comando solo puede usarse dentro del juego.')
    end
end, false)

exports('GetPermanentId', function(src)
    return PlayerPermanentId[src]
end)

exports('GetPermanentIdByIdentifier', function(identifier)
    local result = MySQL.query.await(
        'SELECT id FROM ' .. Config.TableName .. ' WHERE identifier = ?',
        { identifier }
    )
    if result and result[1] then
        return result[1].id
    end
    return nil
end)

exports('GetDataByPermanentId', function(permanentId)
    local result = MySQL.query.await(
        'SELECT * FROM ' .. Config.TableName .. ' WHERE id = ?',
        { permanentId }
    )
    if result and result[1] then
        return result[1]
    end
    return nil
end)