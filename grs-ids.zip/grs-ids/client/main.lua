local PermanentId = nil
local menuOpen = false

local ShowIds = false
local PlayersIdMap = {} -- [serverId] = permanentId

CreateThread(function()
    Wait(1500)
    TriggerServerEvent('grs-ids:requestId')
end)

RegisterNetEvent('grs-ids:setId', function(id)
    PermanentId = id
    if Config.Debug then
        print(('[grs-ids] Tu ID permanente es: %s'):format(tostring(id)))
    end
end)

RegisterCommand(Config.AdminCommand, function()
    if menuOpen then return end
    TriggerServerEvent('grs-ids:requestOpen')
end, false)

RegisterNetEvent('grs-ids:openMenu', function(data)
    menuOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        myId = data.myId,
        myName = data.myName,
        list = data.list
    })
end)

RegisterNUICallback('close', function(_, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    cb('ok')
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() and menuOpen then
        SetNuiFocus(false, false)
        menuOpen = false
    end
end)

exports('GetMyPermanentId', function()
    return PermanentId
end)

RegisterNetEvent('grs-ids:syncIds', function(list)
    local map = {}
    for _, entry in ipairs(list) do
        map[entry.src] = entry.id
    end
    PlayersIdMap = map
end)

RegisterCommand(Config.ViewIdsCommand, function()
    TriggerServerEvent('grs-ids:toggleViewIds')
end, false)

local function Notify(msg, notifyType)
    notifyType = notifyType or 'inform'

    if GetResourceState('es_extended') == 'started' then
        TriggerEvent('esx:showNotification', msg)
    elseif GetResourceState('qbx_core') == 'started' or GetResourceState('qb-core') == 'started' then
        TriggerEvent('QBCore:Notify', msg, notifyType)
    else
        TriggerEvent('chat:addMessage', {
            args = { '^2GRS-IDs', msg }
        })
    end
end

RegisterNetEvent('grs-ids:toggleViewIdsClient', function()
    ShowIds = not ShowIds

    Notify(
        ShowIds and 'Ids activadas' or 'Ids desactivadas',
        'success'
    )
end)

local function DrawText3D(x, y, z, text)
    local onScreen, screenX, screenY = World3dToScreen2d(x, y, z)
    if not onScreen then return end

    local camCoords = GetGameplayCamCoords()
    local dist = #(vector3(camCoords.x, camCoords.y, camCoords.z) - vector3(x, y, z))

    local scale = (1 / dist) * 2
    local fov = (1 / GetGameplayCamFov()) * 100
    scale = scale * fov * Config.ViewIdsTextScale

    SetTextScale(scale, scale)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextOutline()
    SetTextEntry('STRING')
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(screenX, screenY)
end

CreateThread(function()
    while true do
        local sleep = 1000

        if ShowIds then
            sleep = 0

            local myPed = PlayerPedId()
            local myCoords = GetEntityCoords(myPed)

            for _, playerId in ipairs(GetActivePlayers()) do
                if playerId ~= PlayerId() then
                    local targetPed = GetPlayerPed(playerId)

                    if targetPed ~= 0 and DoesEntityExist(targetPed) then
                        local targetCoords = GetEntityCoords(targetPed)
                        local dist = #(myCoords - targetCoords)

                        if dist < Config.ViewIdsRange then
                            local serverId = GetPlayerServerId(playerId)
                            local permId = PlayersIdMap[serverId]

                            if permId then
                                DrawText3D(targetCoords.x, targetCoords.y, targetCoords.z + 1.0, ('ID #%d'):format(permId))
                            end
                        end
                    end
                end
            end
        end

        Wait(sleep)
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        ShowIds = false
    end
end)