Config = {}

Config.Identifier = 'license'
Config.TableName = 'guerrero_ids'

Config.Debug = false
Config.NotifyOnJoin = false

Config.Command = 'id'
Config.AdminCommand = 'adminids'

Config.PermissionMode = 'group' -- 'ace' | 'group'

Config.AdminPermission = 'grsids.admin'
Config.AdminGroups = { 'admin', 'superadmin', 'god' }

Config.CacheTTL = 5000

Config.ViewIdsCommand = 'verid'
Config.ViewIdsAdminOnly = false
Config.ViewIdsRange = 15.0
Config.ViewIdsTextScale = 0.35